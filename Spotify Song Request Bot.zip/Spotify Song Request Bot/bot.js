require('dotenv').config();
const tmi = require('tmi.js');
const axios = require('axios');
const express = require('express');
const open = (...args) => import('open').then(m => m.default(...args));

const app = express();

// CONFIG
const {
  SPOTIFY_CLIENT_ID,
  SPOTIFY_CLIENT_SECRET,
  SPOTIFY_REDIRECT_URI,
  TWITCH_CHANNEL,
  TWITCH_BOT_USERNAME,
  TWITCH_OAUTH
} = process.env;

let accessToken = '';
let refreshToken = '';

// ===== SPOTIFY AUTH =====
app.get('/login', (req, res) => {
  const scope = 'user-modify-playback-state user-read-playback-state';

  const url =
    `https://accounts.spotify.com/authorize?response_type=code` +
    `&client_id=${SPOTIFY_CLIENT_ID}` +
    `&scope=${encodeURIComponent(scope)}` +
    `&redirect_uri=${encodeURIComponent(SPOTIFY_REDIRECT_URI)}`;

  res.redirect(url);
});

app.get('/callback', async (req, res) => {
  const code = req.query.code;

  try {
    const response = await axios.post(
      'https://accounts.spotify.com/api/token',
      new URLSearchParams({
        grant_type: 'authorization_code',
        code,
        redirect_uri: SPOTIFY_REDIRECT_URI
      }),
      {
        headers: {
          Authorization:
            'Basic ' +
            Buffer.from(
              `${SPOTIFY_CLIENT_ID}:${SPOTIFY_CLIENT_SECRET}`
            ).toString('base64'),
          'Content-Type': 'application/x-www-form-urlencoded'
        }
      }
    );

    accessToken = response.data.access_token;
    refreshToken = response.data.refresh_token;

    res.send('✅ Spotify connected. You can close this.');

    // Auto refresh
    setInterval(async () => {
      const r = await axios.post(
        'https://accounts.spotify.com/api/token',
        new URLSearchParams({
          grant_type: 'refresh_token',
          refresh_token: refreshToken
        }),
        {
          headers: {
            Authorization:
              'Basic ' +
              Buffer.from(
                `${SPOTIFY_CLIENT_ID}:${SPOTIFY_CLIENT_SECRET}`
              ).toString('base64'),
            'Content-Type': 'application/x-www-form-urlencoded'
          }
        }
      );

      accessToken = r.data.access_token;
      console.log('🔄 Spotify token refreshed');
    }, 1000 * 60 * 50);

  } catch (err) {
    console.error(err.response?.data || err.message);
    res.send('Auth failed');
  }
});

// Start server
app.listen(8888, () => {
  console.log('🔐 Login at http://127.0.0.1:8888/login');
  open('http://127.0.0.1:8888/login');
});

// ===== TWITCH BOT =====
const client = new tmi.Client({
  identity: {
    username: TWITCH_BOT_USERNAME,
    password: TWITCH_OAUTH
  },
  channels: [TWITCH_CHANNEL]
});

client.connect();

// Add song to Spotify
async function addSong(query) {
  if (!accessToken) return null;

  try {
    const search = await axios.get(
      `https://api.spotify.com/v1/search?q=${encodeURIComponent(query)}&type=track&limit=1`,
      {
        headers: { Authorization: `Bearer ${accessToken}` }
      }
    );

    const track = search.data.tracks.items[0];
    if (!track) return null;

    await axios.post(
      `https://api.spotify.com/v1/me/player/queue?uri=${track.uri}`,
      {},
      {
        headers: { Authorization: `Bearer ${accessToken}` }
      }
    );

    return `${track.name} - ${track.artists[0].name}`;

  } catch (err) {
    console.error(err.response?.data || err.message);
    return null;
  }
}

// Commands
client.on('message', async (channel, tags, message, self) => {
  if (self) return;

  const [command, ...rest] = message.split(' ');
  const query = rest.join(' ');

  if (command === '!sr') {
    if (!query) {
      client.say(channel, `@${tags.username} give a song name.`);
      return;
    }

    const result = await addSong(query);

    if (result) {
      client.say(channel, `🎵 Added: ${result}`);
    } else {
      client.say(channel, `❌ Couldn't add song.`);
    }
  }
});