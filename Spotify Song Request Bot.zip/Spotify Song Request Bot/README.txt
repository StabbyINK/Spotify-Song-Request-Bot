SPOTIFY TWITCH SONG REQUEST BOT

SETUP:

1. Install Node.js
2. Open this folder in Command Prompt

3. Run:
npm install

4. Create a .env file with:

SPOTIFY_CLIENT_ID=
SPOTIFY_CLIENT_SECRET=
SPOTIFY_REDIRECT_URI=http://127.0.0.1:8888/callback

TWITCH_CHANNEL=
TWITCH_BOT_USERNAME=
TWITCH_OAUTH=

5. Run:
node bot.js

6. Open:
http://127.0.0.1:8888/login

7. Done

COMMAND:
!sr song - artist 

EXAMPLE IN CHAT
2:47 StabbyINK: !sr A Work of Art - Ice Nine Kills
2:47 StabbyINK: 🎵 Added: A Work of Art - Ice Nine Kills